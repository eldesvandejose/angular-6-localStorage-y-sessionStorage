import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataPackService } from './services/data-pack.service';
import { GlobalsModule } from './globals/globals.module';
import { MembersModule } from './members/members.module';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    GlobalsModule,
    MembersModule,
    HttpClientModule
  ],
  providers: [
    DataPackService
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
