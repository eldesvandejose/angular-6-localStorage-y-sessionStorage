import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MembersRoutingModule } from './members-routing.module';
import { HttpConnectService } from './services/http-connect.service';
import { MemberFormComponent } from './member-form/member-form.component';
import { MembersListComponent } from './members-list/members-list.component';

@NgModule({
  imports: [
    FormsModule,
    CommonModule,
    MembersRoutingModule
  ],
  declarations: [
    MemberFormComponent,
    MembersListComponent
  ],
  providers: [
    HttpConnectService
  ]
})
export class MembersModule { }
